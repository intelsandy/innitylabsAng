export class MomData {
  department: string;
  date: string;
  time: string;
}
