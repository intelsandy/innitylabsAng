import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meeting-summary',
  templateUrl: './meeting-summary.component.html',
  styleUrls: ['./meeting-summary.component.scss']
})
export class MeetingSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
