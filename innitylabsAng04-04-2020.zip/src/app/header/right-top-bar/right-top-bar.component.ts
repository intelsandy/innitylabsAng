import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-top-bar',
  templateUrl: './right-top-bar.component.html',
  styleUrls: ['./right-top-bar.component.scss']
})
export class RightTopBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
